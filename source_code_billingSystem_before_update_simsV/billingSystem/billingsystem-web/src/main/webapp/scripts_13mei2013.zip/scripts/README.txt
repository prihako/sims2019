The majority of files in this directory come from Prototype
and Scriptaculous - two JavaScript libraries that make Ajax
easier.

http://prototype.conio.net (version 1.5.0_rc1)
http://script.aculo.us (version 1.6.4)

The Prototype framework consists of a single file: prototype.js.

The Script.aculo.us framework consists of six files:

builder.js
controls.js
dragdrop.js
effects.js
scriptaculous.js
slider.js

By including scriptaculous.js in your pages, all the rest of
the files are included as well.

----------------

For good documentation about prototype, see:

http://particletree.com/features/quick-guide-to-prototype

...and...

http://www.sergiopereira.com/articles/prototype.js.html

----------------

The best scriptaculous documentation is at:

http://wiki.script.aculo.us/scriptaculous/show/HomePage

